#reservation form
from django import forms
from .models import Reservation

class ReservationForm(forms.ModelForm):
    class Meta:
        model = Reservation
        fields = ['first_name', 'second_name', 'email', 'phone', 'date', 'time', 'number_of_people', 'special_requests']
        widgets = {
           'first_name': forms.TextInput(attrs={'placeholder': 'Your First Name', 'class': 'form-control'}),
            'second_name': forms.TextInput(attrs={'placeholder': 'Your Last Name', 'class': 'form-control'}),
            'email': forms.EmailInput(attrs={'placeholder': 'Your Email', 'class': 'form-control'}),
            'phone': forms.TextInput(attrs={'placeholder': 'Your Phone Number', 'class': 'form-control'}),
            'date': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'time': forms.TimeInput(attrs={'type': 'time', 'class': 'form-control'}),
            'number_of_people': forms.NumberInput(attrs={'class': 'form-control'}),
            'special_requests': forms.Textarea(attrs={'placeholder': 'Any special requests?', 'class': 'form-control'}),
        }
