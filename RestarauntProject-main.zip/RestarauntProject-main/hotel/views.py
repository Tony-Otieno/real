from django.shortcuts import render, redirect
from .models import Menu, Reservation
from .forms import ReservationForm
import uuid
from django.http import HttpResponse
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from io import BytesIO
import logging
from django.templatetags.static import static
import os
from django.conf import settings


# Create your views here.
def index(request):
    return render(request, 'hotel/index.html', {})

def menu_view(request):
    items = Menu.objects.all()
    return render(request, 'restaurant/menu.html', {'items': items})

#Reservation view
def reservation_view(request):
    if request.method == 'POST':
        form = ReservationForm(request.POST)
        if form.is_valid():
            reservation = form.save()
            # Generate a unique session ID or use Django's session_key
            session_id = request.session.session_key or uuid.uuid4()
            request.session['reservation_session_id'] = reservation.id
            # Save the session key if it was generated anew
            if not request.session.session_key:
                request.session.save()
            return render(request, 'hotel/reciept.html', {'reservation': reservation, 'session_id': session_id})
    else:
        form = ReservationForm()
    return render(request, 'hotel/reservation.html', {'form': form})


#Printing Reservation
#This view ensures the downoload button for the reservation reciept is functional. It helps to generate pdf reciepts for the user

from django.conf import settings
from django.templatetags.static import static
import os

def download_reservation(request, reservation_id):
    try:
        reservation = Reservation.objects.get(pk=reservation_id)

        response = HttpResponse(content_type='application/pdf')
        response['Content-Disposition'] = f'attachment; filename="reservation_{reservation_id}.pdf"'

        buffer = BytesIO()
        p = canvas.Canvas(buffer, pagesize=letter)
        width, height = letter

        # Retrieve the static file URL
        logo_url = static('assets/img/restaurant-logo-template.png')

        # Resolve URL to an absolute path
        logo_path = os.path.join(settings.BASE_DIR, 'static', 'assets', 'img', 'restaurant-logo-template.png')
       

        # Add Header with the logo
        p.drawImage(logo_path, 50, height - 100, width=150, preserveAspectRatio=True)
        p.setFont("Helvetica-Bold", 16)
        p.drawString(50, height - 120, "Kibandaski Pro")
        p.setFont("Helvetica", 12)
        p.drawString(50, height - 140, "Tmall Second Floor, Number 283")
        p.drawString(50, height - 160, "Langata Road")
        p.drawString(50, height - 180, "Phone: (+254) 456-7890-456")

        # PDF content
        p.setFont("Helvetica-Bold", 14)
        p.drawString(100, height - 220, "Reservation Confirmation")

        p.setFont("Helvetica", 12)
        p.drawString(100, height - 240, f"Name: {reservation.first_name} {reservation.second_name}")
        p.drawString(100, height - 260, f"Email: {reservation.email}")
        p.drawString(100, height - 280, f"Date: {reservation.date}")
        p.drawString(100, height - 300, f"Time: {reservation.time}")
        p.drawString(100, height - 320, f"Guests: {reservation.number_of_people}")
        p.drawString(100, height - 340, f"Session ID: {request.session.session_key}")

        # Add Footer
        p.setFont("Helvetica", 10)
        p.drawString(50, 50, "Where Every Bite Tells a Story")
        p.drawString(50, 30, "Follow us on social media: Kibabdaski Pro")

        p.showPage()
        p.save()

        pdf = buffer.getvalue()
        buffer.close()

        response.write(pdf)
        return response
    except Reservation.DoesNotExist:
        return HttpResponse("Reservation not found.", status=404)

    