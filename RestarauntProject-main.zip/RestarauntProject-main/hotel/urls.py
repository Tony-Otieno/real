from django.urls import path 
from .views import (
    index,
    reservation_view,
    download_reservation,
)

urlpatterns = [
    path('', index, name='index' ),
    path('reservation/', reservation_view, name='reservation'),   
    path('download_reservation/<int:reservation_id>/', download_reservation, name='download_reservation'),

   
]
    
