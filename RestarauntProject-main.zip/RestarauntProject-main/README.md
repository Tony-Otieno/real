# RestarauntProject
This is a Restaurant Project for SCITT Class

## Installation

To set up the project on your local machine, follow these steps:

1. **Clone the repository**:
    ```bash
    git clone https://github.com/bobby-850/RestarauntProject.git
    cd RestarauntProject
    ```

2. **Activate the virtual environment**:
    ```bash
    venv\Scripts\activate`
    ```

3. **Install the required dependencies**:
    ```bash
    pip install -r requirements.txt
    ```

4. **Apply migrations** to set up the database:
    ```bash
    python manage.py migrate
    ```

5. **Create a superuser** to access the Django admin:
    ```bash
    python manage.py createsuperuser
    ```

6. **Run the development server**:
    ```bash
    python manage.py runserver
    ```

The application should now be running at `http://127.0.0.1:8000/`.

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reservation Form</title>
    <link rel="stylesheet" href="{% static 'css/styles.css' %}">
</head>
<body>
    <div class="bazuu-form-wrapper">
        <div class="bazuu-form-container">
            <img src="{% static 'assets/img/logo.png' %}" alt="Logo" class="bazuu-logo">
            <h2 class="bazuu-form-header">Reservation Form</h2>
            <form method="post">
                {% csrf_token %}
                {{ form.as_p }}
                <button type="submit" class="bazuu-btn-submit">Submit</button>
            </form>
        </div>
    </div>
</body>
</html>


/* Wrapper for centering the form */
.bazuu-form-wrapper {
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh; /* Full viewport height */
    background-color: #e9ecef; /* Light background color */
}

/* Container for the form */
.bazuu-form-container {
    width: 100%;
    max-width: 600px; /* Limit the maximum width */
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    background-color: #f8f9fa;
    text-align: center; /* Center align content inside container */
}

/* Style for the logo */
.bazuu-logo {
    max-width: 200px; /* Adjust the size as needed */
    margin-bottom: 20px; /* Space between logo and header */
}

/* Header style */
.bazuu-form-header {
    margin-bottom: 20px;
    font-size: 24px;
    font-weight: bold;
    color: #333;
}

/* Form element styles */
form {
    display: flex;
    flex-direction: column;
}

/* Style for form inputs */
.bazuu-form-control {
    width: 100%;
    padding: 10px;
    margin-bottom: 15px;
    border: 1px solid #ccc;
    border-radius: 4px;
    font-size: 16px;
    box-sizing: border-box;
}

.bazuu-form-control:focus {
    border-color: #007bff;
    outline: none;
    box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
}

/* Style for the submit button */
.bazuu-btn-submit {
    width: 100%;
    padding: 10px;
    background-color: #007bff;
    border: none;
    border-radius: 4px;
    color: #fff;
    font-size: 16px;
    cursor: pointer;
    transition: background-color 0.3s;
}

.bazuu-btn-submit:hover {
    background-color: #0056b3;
}
.